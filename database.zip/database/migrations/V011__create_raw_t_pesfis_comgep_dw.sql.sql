-- ============================================================
-- PromocoesCOMAER
-- Migration V011
-- Criação da tabela RAW da T_PESFIS_COMGEP_DW
-- ============================================================

CREATE SCHEMA IF NOT EXISTS raw;

CREATE TABLE IF NOT EXISTS raw.t_pesfis_comgep_dw
(

    nr_ordem              VARCHAR(10) PRIMARY KEY,

    nr_antig              VARCHAR(20),

    nm_pessoa             VARCHAR(200),

    nm_guerra             VARCHAR(100),

    sg_posto              VARCHAR(5),

    sg_qdr                VARCHAR(20),

    sg_org                VARCHAR(120),

    dt_nasc               DATE,

    dt_praca              DATE,

    dt_promocao_atual     DATE,

    dt_conc_frm           DATE,

    dt_mov_atual          DATE,

    dt_apres_atual        DATE,

    dt_ult_apres          DATE,

    sg_sit_qdr            VARCHAR(20),

    nr_sit_qdr            INTEGER,

    st_mov                CHAR(1),

    st_veterano           CHAR(1),

    st_especial           CHAR(1),

    vl_med_cfr            NUMERIC(5,2),

    tx_tempo_servico      VARCHAR(40),

    cd_posto              INTEGER,

    cd_qdr                INTEGER,

    created_at            TIMESTAMP DEFAULT NOW(),

    updated_at            TIMESTAMP DEFAULT NOW()

);

CREATE INDEX idx_raw_posto
ON raw.t_pesfis_comgep_dw (sg_posto);

CREATE INDEX idx_raw_qdr
ON raw.t_pesfis_comgep_dw (sg_qdr);

CREATE INDEX idx_raw_antig
ON raw.t_pesfis_comgep_dw (nr_antig);